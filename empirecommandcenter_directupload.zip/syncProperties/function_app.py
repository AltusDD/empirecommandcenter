import azure.functions as func
import logging

app = func.FunctionApp()

@app.function_name(name="syncProperties")
@app.route(route="syncProperties", auth_level=func.AuthLevel.ANONYMOUS)
def sync_properties(req: func.HttpRequest) -> func.HttpResponse:
    name = req.params.get('name')
    if not name:
        try:
            req_body = req.get_json()
            name = req_body.get('name')
        except:
            name = "World"
    return func.HttpResponse(f"Hello, {name}. This HTTP triggered function executed successfully.")
